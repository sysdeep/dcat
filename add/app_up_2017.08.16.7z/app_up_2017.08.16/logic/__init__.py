#!/usr/bin/env python
# -*- coding: utf-8 -*-


from .main import get_tree, load_tree, load_tree_demo, store_tree


# from .loader import load_tree
# INSTANCE_OF_TREE = None
#
#
# def get_tree():
# 	global INSTANCE_OF_TREE
# 	if INSTANCE_OF_TREE is None:
# 		INSTANCE_OF_TREE = load_tree()
#
# 	return INSTANCE_OF_TREE