#!/bin/env python
#-*- coding: utf-8 -*-
#walkdir.py


import os, string, sys
#import sqlite3
import platform
import time

#PyQt imports
from PyQt4.QtCore import *
from PyQt4.QtGui import *

#dcat imports
#import dcat
#import dcat.gui
import gui.add_progress_dlg

#=======================================================================
#



class WD(QWidget):
    def __init__(self, parent=None):
    
        self.wd()
        self.timer()


    def wd(self):
        
        dialog = gui.add_progress_dlg.Add_progress_dlg()
        
        dialog.show()



    def timer(self):
        dialog = gui.add_progress_dlg.Add_progress_dlg()
        for x in range(10):
            
            dialog.addLabel.setText(str(x))
            time.sleep(1)
            print x



class Walkdir(object):
    def __init__(self, parent=None):
        
        pass
    
    
    #======================================
    def add_node(self, cu, lk, name):	#add node
	
        '''
        add_node(cu, lk, name)
        заносим запись в базу
        in:  	cu.cursor, lk, name
        out: 	---
        '''
        row = self.get_from_lk(cu, lk)
        #level=self.get_from_lk(cu, lk)[1]
        #rk=self.get_from_lk(cu, lk)[0]
        level = row[1]
        rk = row[0]
        
        query1="UPDATE tree SET lk = lk + 2, rk = rk + 2 WHERE lk > "+str(rk)+""
        query2="UPDATE tree SET rk = rk + 2 WHERE rk >= "+str(rk)+" AND lk < "+str(rk)+""
        query3="INSERT INTO tree (lk, rk, level, name) values ("+str(rk)+", "+str((rk+1))+", "+str((level+1))+", '"+name+"')"
        cu.execute(query1)
        cu.execute(query2)
        cu.execute(query3)
        
        
        
    #======================================
    def del_node(self, cu, id, cx):	#del node
	
        '''
        del_node(cu, lk, name)
        удаляем запись из базы
        in:  	cu.cursor, lk
        out: 	---
        '''
        
        row = self.get_from_id(cu, id)
        #("level","rk","lk","id","name")
        
        #level = str(row[2])
        lk = str(row[2])
        rk = str(row[1])
        
        query1 = "DELETE FROM tree WHERE lk >= "+lk+" AND rk <= "+rk+""
        query2 = "UPDATE tree SET rk = rk - ("+rk+" - "+lk+" + 1) WHERE rk > "+rk+" AND lk < "+lk+""
        query3 = "UPDATE tree SET lk = lk - ("+rk+" - "+lk+" + 1), rk = rk - ("+rk+" - "+lk+" + 1) WHERE lk > "+rk+""
        cu.execute(query1)
        cu.execute(query2)
        cu.execute(query3)
        cx.commit()
        
        
        
             
        
    #======================================
    def get_from_id(self, cu, id):
        '''
        get_from_lk(cu, id)
        получаем данные по id
        in:  	cu.cursor, id
        out: 	("level","rk","lk","id","name")
        '''
    
        query_search_node="select level, rk, lk, id, name from tree WHERE id="+str(id)+""
        cu.execute(query_search_node)
        row=cu.fetchone()
        return row
        
        
    def get_from_level(self, cu, level):
        '''
        get_from_level(cu, level)
        получить данные всех элементов заданного уровня
        in:     cu
                level
        out:    [("level","rk","lk","id","name"),("","")]
        '''
        
        query = "SELECT level, rk, lk, id, name FROM tree WHERE level = '"+str(level)+"'"
        cu.execute(query)
        row = cu.fetchall()
        return row


        
    #======================================
    def get_from_lk(self, cu, lk):
    
        '''
        get_from_lk(cu, lk)
        получаем данные по левому ключу
        in:  	cu.cursor, lk
        out: 	list(rk, level, name)
        '''
    
        query_search_node="select rk, level, name from tree WHERE lk="+str(lk)+""
        cu.execute(query_search_node)
        row=cu.fetchone()
        return row



    #======================================
    def search_valid_parent(self, cu, root):
    
        '''
        search_valid_parent(cu, root)
        поиск lk правильного предка
        in:	    cu.cursor, root(путь от корня нашей базы: root/item1/dir1)
        out:	lk
        '''
    
        #root = ["root", "item1", "dir1"] - dir1 - #имя предка 
        name=root[len(root)-1]        #имя предка
        
        #ищем все lk с именем name
        query = "SELECT lk, rk FROM tree where name='"+name+"'"
        cu.execute(query)
        row=cu.fetchall()   #lk и rk всех элементов с именем name
    
        #для всех значений ищем предка
        #если нашли первый совпадающий - то выходим и возвращаем текущий lk
        for x in row:
            lk = x[0]
            rk = x[1]
            #ищем для текущего name путь предков
            query ="SELECT name FROM tree WHERE lk <= "+str(lk)+" AND rk >= "+str(rk)+" ORDER BY lk"
            cu.execute(query)
            row=cu.fetchall() #[ (u'root'), ('item1') ]
                
            #теперь последовательно сравниваем значения из root и row
            #root=[ u'root', 'item1' ], row=[ (u'root'), ('item1') ]
            flag="false"    #флаг
            c=0             #начальный элемент
        
            for z in row:
                a = root[c]     #'root', 'item1'
                b = z[0].encode("utf8")        #'root', item1(из unikode в str)
                if a==b:
                    pass        #flag остается false
                else:
                    flag="true" #несовпадение
                    break
                c=c+1
            
                
            #если полное совпадение, то выходим из цикла и возвращаем lk
            if flag=="false":
                break
                   
        return lk
        
        
        
    #================
    def walkdir(self, dir, cu, name_item, cx):
    
        '''
        walkdir(dir, cu, name_item, cx)
        дерево дир в базу
        in:	    dir - откуда начинается сканирование(срока должна заканчиавться /), 
                cu.cursor, 
                cx - индефикатор базы
                name_item - имя нашего раздела(item1) 
        out:	---
        '''
	
        #добавляем в базу название нашего раздела
        #ищем lk у корня
        query = "SELECT lk FROM tree WHERE level=0"
        cu.execute(query)
        row=cu.fetchone()   #(int,)
        
          
        lk = row[0]
        self.add_node(cu, lk, name_item)
        
        #ищем lk нашего добавленного раздела
        query = "SELECT lk, rk FROM tree WHERE name='"+name_item+"' AND level=1"
        cu.execute(query)
        row=cu.fetchone()   #(2,3)
          
        lk = row[0]
        rk = row[1]
        
        #prefix=["root", "label1"]    #root/+наш раздел
        prefix=["root"]    #root/+наш раздел
        prefix.append(name_item)
        
        #разбиваем путь на лист
        #нужно для последующего отсеивания этого пути
        rdirs = string.split(dir, "/")
                
            
        flag = "false"  #нужен для отлова 1 прохода
        #в цикле обходим все диры
        for root, dirs, files in os.walk(dir):
            #root - текущий путь(от корня) в данной итерации
            #dirs - список дир в данной итерации
            #files - список фаилов в данной итерации
        
            #если 1 раз, то не ищем предка
            if flag=="false":   
                flag="true"     #и сразу ставим другой флаг
            else:   #в противном случае - ищем
                #если платформа Windows, то разбиваем по другому                
                if platform.system()=="Windows":
                    #root = "C:/dir1\dir11\dir21..."
                    #разбиваем путь по \, в 1 части будет: C:/dir, во всех остальных - паздельный путь
                    zzz=string.split(root, "\\")
                    #разбиваем первый элемент по /
                    roots=string.split(zzz[0],"/")
                    #избавляемся от 1 элемента
                    zzz.remove(zzz[0])
                    #в цикле добавляем остальное из zzz к roots
                    for x in zzz:
                        roots.append(x)
                        
                    #избавляемся от системного префикса 
                    #для windows - весь диапазон ("c:", "bin", "ls")
                    for x in range(len(rdirs)):
                        roots.remove(roots[0])  #удаляем по одному с начала
                   
                #если Linux = просто разбиваем    
                elif platform.system()=="Linux":
                    roots=string.split(root,"/")		#разбиваем строку ("","path1","path2")
                               
                    #избавляемся от системного префикса
                    #для linux - диапазон - 1   ("", "bin", "ls")
                    for x in range(len(rdirs)-1):
                        roots.remove(roots[0])  #удаляем по одному с начала
                    
                new_root=prefix+roots       # root, item1 + дальнейшие элементы
            
                #ищем lk от правильного предка 
                lk=self.search_valid_parent(cu, new_root)
                        
            if(dirs):
                for x in dirs:      #x - name
                    self.add_node(cu, lk, x)
		
        
            if(files):	
                for x in files:     #x - name
                    self.add_node(cu, lk, x)
				
            #подтверждение транзакции(иначе в поиске предков ничего не выберется(()
            cx.commit()
        

#=======================================================================


    def walkdir1(self, dir, cu, name_item, cx):
        if platform.system()=="Windows":
            rdirs = string.split(dir, "/")
        elif platform.system()=="Linux":
            rdirs = string.split(dir, "/")
        return rdirs
  
  
  
  
    def create_new_db(self, cu, cx):
        '''
        create_new_db(cu, cx)
        создание новой базы и инициализация начальных значений
        in:     cu
                cx
        out:    
        '''
        
        dcat_version = dcat.PROGRAM_VERSION_TEXT
        
        query1 = "CREATE TABLE tree (level int(10), rk int(10), lk int(10), id integer PRIMARY KEY, name varchar(150))"
        query2 = "INSERT INTO tree(level, rk, lk, name) VALUES(0, 2, 1, 'root')"
        query3 = "CREATE TABLE sys (version varchar(5))"
        query4 = "INSERT INTO sys(version) VALUES("+dcat_version+")"
        cu.execute(query1)
        cu.execute(query2)
        cu.execute(query3)
        cu.execute(query4)
        cx.commit()
  
  
    def get_system_info(self, cu):
        '''
        get_system_info(cu)
        in:     cu - индефикатор базы
        out:    [("version",)]
         '''
        
        query = "SELECT version FROM sys"
        cu.execute(query)
        row = cu.fetchall()
        return row
  
  
    def get_all_children(self, cu, lk, rk, level):
        '''
        get_all_children(lk, rk, level)
        получаем всех потомков первого уровня заданного узла
        in:     lk      (int)
                rk      (int)
                level   (int)
        out:    [("level","rk","lk","id","name"), (...)]
        '''
        lk=str(lk)
        rk=str(rk)
        query = "SELECT level, rk, lk, id, name FROM tree WHERE lk > "+lk+" AND rk < "+rk+" AND level = "+str(level+1)+" ORDER BY lk"
        cu.execute(query)
        row = cu.fetchall()
        return row
  
    def get_parent(self, cu, lk, rk, level):
        '''
        get_parent(lk, rk, level)
        получаем всех потомков первого уровня заданного узла
        in:     lk      (int)
                rk      (int)
                level   (int)
        out:    [("level","rk","lk","id","name"), (...)]
        '''
        lk=str(lk)
        rk=str(rk)
        query = "SELECT level, rk, lk, id, name FROM tree WHERE lk < "+lk+" AND rk > "+rk+" AND level = "+str(level-1)+""
        cu.execute(query)
        row = cu.fetchone()
        return row
  
        
    def get_full_parents(self, cu, lk, rk):
        '''
        get_full_parents(cu, lk, rk)
        получить полный список родителей от корня
        in:     cu
                lk
                rk
        out:    ("root", "name1", "...")
        '''
        query = "SELECT name FROM tree WHERE lk <= "+str(lk)+" AND rk >= "+str(rk)+" "
        cu.execute(query)
        row=cu.fetchall()
        return row
  
  
    def tst_name_flevel(self, cu, name):
        '''
        tst_name_flevel(cu, name)
        проверка нового имени на наличие в базе - 1 level(имена не должны повторятся)
        in:     cu
                name - имя 
        out:    true | false
        '''
        query = "SELECT name FROM tree WHERE name='"+name+"' and level = 1"
        cu.execute(query)
        row = cu.fetchall() 
        
        #если нет значений - тогда false 
        if len(row)==0:
            return "false"
        else:
            return "true"

    def update_name_flevel(self, cx, cu, oldname, newname):
        '''
        update_name_flevel(cu, oldname, newname)
        обновление имени для 1 level
        in:     cu
                oldname - 
                newname - 
        out:    --
        '''
        query = "UPDATE tree SET name = '"+newname+"' WHERE name = '"+oldname+"' and level = 1"
        cu.execute(query)
        cx.commit()

if __name__ == "__main__":
    #import sys
    
    app = QApplication(sys.argv)
    form = WD()
    form.show()
    app.exec_()
