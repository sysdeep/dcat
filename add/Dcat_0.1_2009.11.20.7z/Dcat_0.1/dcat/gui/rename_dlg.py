# -*- coding: utf-8 -*-
#rename_dlg.py
#инициализация диалога переименования новой записи

from PyQt4.QtCore import *
from PyQt4.QtGui import *

import rename_dlg_ui


class Rename_dlg(QDialog, rename_dlg_ui.Ui_renameDialog):
    def __init__(self, name, parent=None):
        super(Rename_dlg, self).__init__(parent)
        
        self.setupUi(self)
        
        #устанавливаем текущее имя в строке релактирования
        self.renameEdit.setText(name)
        self.connect(self.renameButton, SIGNAL("clicked()"), self.set_rename)
        self.connect(self, SIGNAL("CloseSignal"), SLOT("accept()"))
        
        
        
    def set_rename(self):
        
        name = self.renameEdit.text()
        self.emit(SIGNAL("CloseSignal"))
        return name
        
        
        
if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    form = Rename_dlg()
    form.show()
    app.exec_()
            
