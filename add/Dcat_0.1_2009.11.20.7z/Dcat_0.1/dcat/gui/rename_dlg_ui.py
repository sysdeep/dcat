# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file './dcat/rc/rename_dlg.ui'
#
# Created: Fri Nov 20 13:19:44 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_renameDialog(object):
    def setupUi(self, renameDialog):
        renameDialog.setObjectName("renameDialog")
        renameDialog.resize(240, 47)
        self.horizontalLayout_2 = QtGui.QHBoxLayout(renameDialog)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.renameEdit = QtGui.QLineEdit(renameDialog)
        self.renameEdit.setObjectName("renameEdit")
        self.horizontalLayout.addWidget(self.renameEdit)
        self.renameButton = QtGui.QPushButton(renameDialog)
        self.renameButton.setObjectName("renameButton")
        self.horizontalLayout.addWidget(self.renameButton)
        self.horizontalLayout_2.addLayout(self.horizontalLayout)

        self.retranslateUi(renameDialog)
        QtCore.QMetaObject.connectSlotsByName(renameDialog)

    def retranslateUi(self, renameDialog):
        renameDialog.setWindowTitle(QtGui.QApplication.translate("renameDialog", "Rename", None, QtGui.QApplication.UnicodeUTF8))
        self.renameButton.setText(QtGui.QApplication.translate("renameDialog", "Rename", None, QtGui.QApplication.UnicodeUTF8))

