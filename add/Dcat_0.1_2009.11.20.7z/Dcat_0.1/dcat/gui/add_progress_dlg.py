# -*- coding: utf-8 -*-
#add_progress_dlg.py
#инициализация диалога переименования новой записи


#python
import time

#PyQt
from PyQt4.QtCore import *
from PyQt4.QtGui import *

#self
import add_progress_dlg_ui


cc = ""


class timer(QThread):
    def __init__(self, output):
        QThread.__init__(self)
        self.output = output
 
    def run(self):
        for x in range(10):
            print x
            #output.setText(x) 
            time.sleep(1)
        #some_big_function_with_output()




class Add_progress_dlg(QDialog, add_progress_dlg_ui.Ui_addProgressDialog):
    def __init__(self, parent=None):
        super(Add_progress_dlg, self).__init__(parent)
        
        self.setupUi(self)
        
        
        #self.aaa = myQThread()
        
        #self.aaa.run()
        #self.addLabel.setText("")
        
        #self.timer()
        
        #self.connect(self.goButton, SIGNAL("clicked()"), self.aaa.run)
        #self.connect(self, SIGNAL("qqqsignal"), self.zzz)
        
    def zzz(self):
        global cc
        print cc
        self.addLabel.setText(str(cc))
        
               
        
        
    def timer(self):
        global cc
        for x in range(10):
            time.sleep(1)
            cc = x
            self.emit(SIGNAL("qqqsignal"))
            #print x
        
    def qqq(self):
        self.aaa("aaa")
        time.sleep(1)
        self.aaa("bbb")
        
        
    def aaa(self, aa):
        
        self.addLabel.setText(aa)

        #self.connect(self.renameButton, SIGNAL("clicked()"), self.set_rename)
        #self.connect(self, SIGNAL("CloseSignal"), SLOT("accept()"))
        
        
        
    #def set_rename(self):
        
        #name = self.renameEdit.text()
        #self.emit(SIGNAL("CloseSignal"))
        #return name
        
        
        
if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    form = Add_progress_dlg()
    form.show()
    
    timer = Timer(Add_progress_dlg)
    timer.start()


    app.exec_()
            
