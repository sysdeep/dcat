#!/usr/bin/python
# -*- coding: utf-8 -*-


from PyQt4.QtCore import *
from PyQt4.QtGui import *
import main_window_ui

from dcat.sql import Dcat_sql
import os, string
import sqlite3
import platform


#для параметров функции в connect (partial(self.somefunc, arg))
from functools import partial


#dcat imports
import dcat
import dcat.gui
from dcat.sql import Dcat_sql
import add_node_dlg
import rename_dlg
import add_progress_dlg

#глобальные переменные для базы
dcat_version = "0.1"        #version
cx=''                       
cu=''


#=======================================================================
#main class
class Dcat(QMainWindow, main_window_ui.Ui_MainWindow):
    def __init__(self,  parent=None):
        super(Dcat, self).__init__(parent)
        #подгружаем Ui
        self.setupUi(self)
                         
        
        self.setupActions()
        #self.OpenDB()
        self._connections()
        self.pathLabel.setText("")
        #self.contextMenuEvent(self.event)
        
        
        
        



        
#    def contextMenuEvent(self, event):
        #if event.button() == Qt.RightButton:
#        print "aaaaaaaaaaaaaaaaaaaaaaaa"
      
      
      
        #self.updateUi()
        #QMessageBox.aboutQt(self)
        #QMessageBox.information(self, "Create new db", "The was created")
        
    # Другие connections  
    def _connections(self):
        self.connect(self.CloseButton,  SIGNAL("clicked()"),  SLOT("close()"))
        self.connect(self.tablistWidget, SIGNAL("itemClicked(QTreeWidgetItem *, int)"), self.CurTabItem)
        self.connect(self.ltreeWidget, SIGNAL("itemActivated(QTreeWidgetItem *, int)"), self.CurListItem)
        #self.connect(self.AddButton, SIGNAL("clicked()"), self.AddNode)
        #self.connect(self.clearDBButton, SIGNAL("clicked()"), self.ClearDB)
        
        
        #сгналы для вызова контекстного меню
        #для tablistWidget
        self.tablistWidget.setContextMenuPolicy(Qt.CustomContextMenu) 
        self.connect(self.tablistWidget, SIGNAL("customContextMenuRequested(const QPoint &)"), self.tablistCMenu) 
    
    
    
    
    def tablistCMenu(self, point): 
    
        '''
        tablistCMenu(point)
        обработка вызова контекстного меню на tablistWidget
        point - возвращает SIGNAL customContextMenuRequested(const QPoint &) - QPoint
        '''
        
        model_index=self.tablistWidget.indexAt(point) #QModelIndex
        
        #row = model_index.row()     #int - номер строки с 0
             
        #создаем менюшку 
        contextMenu = QMenu()
        contextMenu.addAction("Remove from list", partial(self.removefromtablist, model_index))
        contextMenu.addAction("Rename", partial(self.renamefromtablist, model_index))
        contextMenu.exec_(QCursor.pos())
        
        
    
    def removefromtablist(self, model_index):
        
        '''
        removefromtablist(model_index)
        удаление записи из tablist
        model_index - QModelIndex   - значения выбранного элемента
        '''
        
        #преобразуем в QTreeWidgetItem
        cur_item = self.tablistWidget.itemFromIndex(model_index)
        
        #для удаления надо тока id
        name = cur_item.text(0)
        id = cur_item.text(1)
        
        #подтверждение           
        qmbox = QMessageBox.question(self, 
                                    "Remove node",
                                    "Are you really want to remove "+name+"?",
                                    QMessageBox.Ok,
                                    QMessageBox.Cancel
                                    )
        
        #если ok(1024)                            
        if qmbox==1024:
            
            #print "remove: name ", name, " id ", id
            
            global cx,cu
            
            sqlobj = Dcat_sql()
            sqlobj.del_node(cu, id, cx)
            
            
            #обновляем
            self.View_start()
        
    
    def renamefromtablist(self, model_index):
        
        '''
        renamefromtablist(model_index)
        переименование записи из tablist
        model_index - QModelIndex   - значения выбранного элемента
        '''
    
        #преобразуем в QTreeWidgetItem
        cur_item = self.tablistWidget.itemFromIndex(model_index)
        
        #для удаления надо тока id
        name = cur_item.text(0)
        id = cur_item.text(1)
        
        dialog = dcat.gui.rename_dlg.Rename_dlg(name)
        
        if dialog.exec_():
            newname = str(dialog.set_rename())
            
            name = str(name)
        
        
            #проверяем наличие в базе
            sql_obj = Dcat_sql()
            flag = sql_obj.tst_name_flevel(cu, newname)
            #если нет значений - тогда меняем
            if flag == "false":
            
                sql_obj.update_name_flevel(cx, cu, name, newname)
            
                #обновляем
                self.View_start()
            
            elif flag == "true":    #если - есть - сообщение
                QMessageBox.warning(self, 
                                    "Error",
                                    "Item "+name+" allready in db",
                                    QMessageBox.Ok
                                    )
    
    
    
    
    
    
    
    
    #===================================================================           
    def CurTabItem(self, item):
                
        '''
        CurTabItem()
        Реакция на выбор элементов в tablist
        item - возвращает SIGNAL (QTreeWidgetItem)
        '''
                
        name=item.text(0)           #name
        id = item.text(1)           #id (see TabList)
        text = "Name = "+name+" -- id = "+id
        
        self.statusbar.showMessage(text)
        
        #ищем параметры по id
        sql_obj = Dcat_sql()
        row = sql_obj.get_from_id(cu, str(id))
        #query = "SELECT lk, rk, level FROM tree WHERE id="+str(id)+""
        #cu.execute(query)
        #row=cu.fetchone()
        lk=row[2]
        rk=row[1]
        level=row[0]
        
        
        self.pathLabel.setText("/"+name+"/")
        
        if ((rk-lk)==1):
            pass
        else:
            self.ViewList_update(id, lk, rk, level)
        
    
    #===================================================================    
    def CurListItem(self, item):
        
        '''
        CurListItem(item)
        Обновляет лист элементов в ltreeWidget
        item - возвращает SIGNAL (QTreeWidgetItem)
        '''
                
        #global cx,cu
        #имя
        name=item.text(0)
        #id
        id = item.text(2)         #id (see ltreeWidget)
        
        #statusbar
        text = "Name = "+name+"-- id = "+id
        self.statusbar.showMessage(text)
        
        #print id, type(id)
        
        #ищем параметры по id
        sql_obj = Dcat_sql()
        row = sql_obj.get_from_id(cu, str(id))
        lk=row[2]
        rk=row[1]
        level=row[0]
        
        
       
         
        #поиск предков для строки пути
        
        row = sql_obj.get_full_parents(cu, lk, rk)
        row.remove(row[0])  #избавляемся от "root" в пути
        #если фаил, то в путь не добавляем
        if ((rk-lk)==1):
            row.remove(row[len(row)-1])
        
        #сборка строки(отсеивание)
        pathtext="/"
        for x in row:
             pathtext=pathtext+x[0]+"/"
        self.pathLabel.setText(pathtext)
        
        #если щелчок по файлу - то ничего не делаем
        if ((rk-lk)==1):
            pass
        else:   #если папка - отображаем
            self.ViewList_update(id, lk, rk, level)
        
        
    #===================================================================
    # Реакции на выбор из меню  
    def setupActions(self):
                
        #File
        #FileOpenAction
        self.connect(self.FileOpenAction,  SIGNAL("triggered()"), self.FileOpen)
        #FileNewAction
        self.connect(self.FileNewAction,  SIGNAL("triggered()"), self.FileNew)
        #FileSaveAction
        #self.connect(self.FileSaveAction,  SIGNAL("triggered()"), self.qqq)
        #FileExitAction
        self.connect(self.FileExitAction, SIGNAL("triggered()"), SLOT("close()"))
        
        #EditAddAction
        self.connect(self.EditAddAction,  SIGNAL("triggered()"), self.AddSubject)
        
        
        #Help
        #HelpAboutAction
        self.connect(self.HelpAboutAction,  SIGNAL("triggered()"), self.About_dcat)
        
        #HelpAbout_QtAction
        self.connect(self.HelpAbout_QtAction,  SIGNAL("triggered()"), qApp.aboutQt)
        
        
    #===================================================================    
#    def OpenDB(self):
#        fileName="1.ddb"
        #Пробуем конектиться к db==================
#        global cx,cu
#        fileName=str(fileName)
#        cx=sqlite3.connect(fileName,0777)
#        cu=cx.cursor()
                       
        #statusBar
#        self.statusbar.showMessage("The "+fileName+" was opened")
        
       
                        
#        self.View_start()
        
        
        
        
        
    #===================================================================    
    def FileOpen(self):
        #FileOpen dialog
        fileName=QFileDialog.getOpenFileName(self, "Open db",  
                                                "./", 
                                                "DataBase(*.ddb)")
                                                
        if(fileName.isEmpty()):
            print "No Selected Files!!!!!!!!!!!!"
            
        else:
            
            #Пробуем конектиться к db==================
            global cx,cu
            fileName=str(fileName)
            cx=sqlite3.connect(fileName,0777)
            cu=cx.cursor()
                    
            sql_obj=Dcat_sql()
            row = sql_obj.get_system_info(cu)
                        
            version_db = str(row[0][0])
                        
            #statusBar
            self.statusbar.showMessage("The "+fileName+" was opened, Version = "+version_db+"")
                        
            self.setWindowTitle("Dcat - v"+version_db+" <---> "+fileName)
            
            self.View_start()
            
            
          

    

    #===================================================================
    def FileNew(self):
        #FileNew dialog
        fileName = QFileDialog.getSaveFileName(self, "New bd...",
                                                "./",
                                                "DataBase(*.ddb)")
                             
        fileName = str(fileName)
               
        global cx,cu
        
        try:
            cx=sqlite3.connect(fileName,0777)
        except:
            QMessageBox.warning(self, 
                                    "Warning",
                                    "Can`t creating database "+fileName+"",
                                    QMessageBox.Ok,
                                    )
        else:
            cu=cx.cursor()
                                    
            sql_obj = Dcat_sql()
            sql_obj.create_new_db(cu,cx)
            
            self.statusbar.showMessage("New "+fileName+" was created")
        
            version_db = dcat.PROGRAM_VERSION_TEXT
            self.setWindowTitle("Dcat - v"+version_db+" <---> "+fileName)
            
            self.View_start()
          
        
 
            
            
            
            
    #===================================================================        
    def View_start(self):
        
        '''
        View_start()
        начальное состояние после открытия или изменения в базе
        '''
        
        #очищаем виджеты
        self.ltreeWidget.clear()
        self.tablistWidget.clear()
        
        
        global cx,cu
        basedir = dcat.BASEDIR
        
        
        #получаем всех 1 уровня
        sql_obj = Dcat_sql()
        row = sql_obj.get_from_level(cu, 1)
                
        for x in row:
            #x=(level, rk, lk, id, name)
        
            item = QTreeWidgetItem()        #list
            item.setText(0, x[4])           #name
            item.setText(2, str(x[3]))      #id
            #item.setText(2, str(x[0]))     #level
            #item.setText(3, str(x[1]))     #rk
            #item.setText(4, str(x[2]))     #lk
            
            itemtab = QTreeWidgetItem()     #tablist
            itemtab.setText(0, x[4])        #name
            itemtab.setText(1, str(x[3]))   #id
            #установка иконок для tablist
            itemtab.setIcon(0,(QIcon(QPixmap(basedir+"/rc/images/cdrom.png"))))
            
            #установка иконок для list
            if ((x[1]-x[2])==1):    #rk-lk=1 - file
                item.setIcon(0,(QIcon(QPixmap(basedir+"/rc/images/file.png"))))
            else:                   #rk-lk|=1 - folder
                item.setIcon(0,(QIcon(QPixmap(basedir+"/rc/images/folder.png"))))
            
            self.ltreeWidget.addTopLevelItem(item)
            self.tablistWidget.addTopLevelItem(itemtab)
            
            
            
    #===================================================================        
    def ViewList_update(self, id, lk, rk, level):
        '''
        ViewList_update(id)
        Обновление листа, заполнение его потомками
        id - предок (int)
        lk - -//- (int)
        rk - -//- (int)
        level - -//- (int)
        '''
               
        self.ltreeWidget.clear()
        id=str(id)
        global cx,cu
        
              
        #выбираем всех потомков
        sql_obj = Dcat_sql()
        row_child = sql_obj.get_all_children(cu, lk, rk, level)
        
        
        #если level предка 0 - то не добавляем ..
        if str(level)=="0":
            pass 
        else:
            #поиск предка
            
            parent_row = sql_obj.get_parent(cu, lk, rk, level)
              
            #первая строка в сриске (..)
            ##x=(level, rk, lk, id, name)
            item = QTreeWidgetItem()
            item.setText(0, "..")         #name
            item.setText(2, str(parent_row[3]))    #id
            #item.setText(2, str(parent_row[0]))    #level
            #item.setText(3, str(parent_row[1]))    #rk
            #item.setText(4, str(parent_row[2]))    #lk
            #item.setIcon(0,(QIcon(QPixmap("./rc/images/folder.png"))))
            self.ltreeWidget.addTopLevelItem(item)
        
        basedir = dcat.BASEDIR
        #забиваем список
        for x in row_child:
            
            #x=(level, rk, lk, id, name)
            item = QTreeWidgetItem()
            item.setText(0, x[4])         #name
            item.setText(2, str(x[3]))    #id
            #item.setText(2, str(x[0]))    #level
            #item.setText(3, str(x[1]))    #rk
            #item.setText(4, str(x[2]))    #lk
            if ((x[1]-x[2])==1):
                item.setIcon(0,(QIcon(QPixmap(basedir+"/rc/images/file.png"))))
            else:
                item.setIcon(0,(QIcon(QPixmap(basedir+"/rc/images/folder.png"))))
            self.ltreeWidget.addTopLevelItem(item)
        
        
        
        
    def AddSubject(self):   
        '''
        AddSubject()
        запрос на добавление ресурса и его добавление
        '''
        #вызов диалога выбора директории
        dialog = add_node_dlg.Dcat_add_dlg(self)
        if dialog.exec_():
            text_name, text_path = dialog.addNode()
                #text_name  -   имя 
                #text_path  -   путь
            global cx,cu        
        
            name = str(text_name)
        
        
            #проверка на имеющееся значение
            sql_obj = Dcat_sql()
            flag = sql_obj.tst_name_flevel(cu, name)
            #если нет значений - тогда забиваем 
            if flag == "false":
           
                #забиваем в базу
                sql_obj.walkdir(str(text_path), cu, str(text_name), cx)
            elif flag == "true":
                QMessageBox.warning(self, 
                                    "Error",
                                    "Item "+name+" allready in db",
                                    QMessageBox.Ok
                                    )
            
            
            #обновляем
            self.View_start()
            
            #dialog = add_progress_dlg.Add_progress_dlg(self)
            #dialog.exec_()
            
            
            
        '''
        name_item = str(text_name)
        dir = str(text_path)
        
        sqlobj = Dcat_sql()
        
        #добавляем в базу название нашего раздела
        #ищем lk у корня
        query = "SELECT lk FROM tree WHERE level=0"
        cu.execute(query)
        row=cu.fetchone()   #(int,)
                  
        lk = row[0]
        sqlobj.add_node(cu, lk, name_item)
        
        #ищем lk нашего добавленного раздела
        query = "SELECT lk, rk FROM tree WHERE name='"+name_item+"' AND level=1"
        cu.execute(query)
        row=cu.fetchone()   #(2,3)
          
        lk = row[0]
        rk = row[1]
        
        #prefix=["root", "label1"]    #root/+наш раздел
        prefix=["root"]    #root/+наш раздел
        prefix.append(name_item)
        
        #разбиваем путь на лист
        #нужно для последующего отсеивания этого пути
        rdirs = string.split(dir, "/")
                
            
        flag = "false"  #нужен для отлова 1 прохода
        #в цикле обходим все диры
        for root, dirs, files in os.walk(dir):
            #root - текущий путь(от корня) в данной итерации
            #dirs - список дир в данной итерации
            #files - список фаилов в данной итерации
        
            #если 1 раз, то не ищем предка
            if flag=="false":   
                flag="true"     #и сразу ставим другой флаг
            else:   #в противном случае - ищем
                #если платформа Windows, то разбиваем по другому                
                if platform.system()=="Windows":
                    #root = "C:/dir1\dir11\dir21..."
                    #разбиваем путь по \, в 1 части будет: C:/dir, во всех остальных - паздельный путь
                    zzz=string.split(root, "\\")
                    #разбиваем первый элемент по /
                    roots=string.split(zzz[0],"/")
                    #избавляемся от 1 элемента
                    zzz.remove(zzz[0])
                    #в цикле добавляем остальное из zzz к roots
                    for x in zzz:
                        roots.append(x)
                        
                    #избавляемся от системного префикса 
                    #для windows - весь диапазон ("c:", "bin", "ls")
                    for x in range(len(rdirs)):
                        roots.remove(roots[0])  #удаляем по одному с начала
                   
                #если Linux = просто разбиваем    
                elif platform.system()=="Linux":
                    roots=string.split(root,"/")		#разбиваем строку ("","path1","path2")
                               
                    #избавляемся от системного префикса
                    #для linux - диапазон - 1   ("", "bin", "ls")
                    for x in range(len(rdirs)-1):
                        roots.remove(roots[0])  #удаляем по одному с начала
                    
                new_root=prefix+roots       # root, item1 + дальнейшие элементы
            
                #ищем lk от правильного предка 
                lk=sqlobj.search_valid_parent(cu, new_root)
                        
            if(dirs):
                for x in dirs:      #x - name
                    sqlobj.add_node(cu, lk, x)
		
        
            if(files):	
                for x in files:     #x - name
                    sqlobj.add_node(cu, lk, x)
				
            #подтверждение транзакции(иначе в поиске предков ничего не выберется(()
            cx.commit()
        
        '''
        
        
        
        
                
        
       
    #===================================================================           
    def About_dcat(self):
        QMessageBox.about(self, "About Dcat",
                        """<b>Dcat</b> v %s
                        <p>Copyright &copy; 2009 Dune Ltd.
                        All rights reserved.
                        <p>This application can be used to collect CD`s or oter media.
                        <p>Python %s - Qt %s - PyQt %s on %s""" % (
                        dcat.PROGRAM_VERSION_TEXT, platform.python_version(),
                        QT_VERSION_STR, PYQT_VERSION_STR, platform.system()))

        
        
    
        

if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    form = Dcat()
    form.show()
    app.exec_()
        








