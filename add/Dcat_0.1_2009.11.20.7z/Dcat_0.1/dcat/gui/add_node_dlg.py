# -*- coding: utf-8 -*-
#add_node_dlg.py
#инициализация диалога добавления новой записи


from PyQt4.QtCore import *
from PyQt4.QtGui import *
import string
import add_node_dlg_ui

class Dcat_add_dlg(QDialog, add_node_dlg_ui.Ui_addDialog):
    def __init__(self, parent=None):
        super(Dcat_add_dlg, self).__init__(parent)
        
        self.setupUi(self)
        
        #очищаем метку ошибок
        self.errordlgLabel.setText("")
        #self.adddlgButton.setEnabled(0)
        self._connections()
        
    def _connections(self):
        #событие на нажатии кнопки add
        self.connect(self.adddlgButton, SIGNAL("clicked()"), self.addNode)
        #обытие на нажатии кнопки просмотр директорий
        self.connect(self.openPathButton, SIGNAL("clicked()"), self.openPath)
        #событие после успешного приема данных и нажатии add (see addNode())
        self.connect(self, SIGNAL("CloseSignal"), SLOT("accept()"))
        self.connect(self.canceldlgButton, SIGNAL("clicked()"), SLOT("reject()"))
        
        
    def addNode(self):
        '''
        addNode()
        возвращает имя и путь для новой записи
        '''
        text_name=self.namedlgEdit.text()   #name
        text_path=self.pathdlgEdit.text()   #path
        
        #проверка на введенные данные
        if text_name:
            if text_path:
                #если все введено, отправляем сигнал CloseSignal и возвращаем данные
                self.emit(SIGNAL("CloseSignal"))
                
                return (text_name, text_path)
                
            else:
                #если не введен path
                self.errordlgLabel.setText("none path")
        else:
            #если не введен name
            self.errordlgLabel.setText("none name")
        
        
    def openPath(self):
        '''
        openPath()
        вызов диалога выбора директории
        '''        
        pathName = QFileDialog.getExistingDirectory(self,
                                                    "Open Directory",
                                                    ".",
                                                    QFileDialog.ShowDirsOnly)
        #заносим значение в Edit
        self.pathdlgEdit.setText(pathName)
        #print type(pathName)
        
        #авотматическое заполнение namedlgEdit конечным именем из пути
        text_name=str(self.namedlgEdit.text())
        #если в поле name уже есть значение - тогда не заполняем
        if len(text_name)>0:
            pass
        else:
            #если пусто - заполняем
            #разбиваем строку по /
            path_Name = str(pathName)
            llpath = string.split(path_Name, "/")
            #выбираем последнее значение
            name_item = llpath[len(llpath)-1]
            #заносим в поле name
            self.namedlgEdit.setText(name_item)
        
        
        
if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    form = Dcat_add_dlg()
    form.show()
    app.exec_()
            
