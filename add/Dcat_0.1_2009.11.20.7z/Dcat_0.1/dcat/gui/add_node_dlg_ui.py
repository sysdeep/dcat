# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file './dcat/rc/add_node_dlg.ui'
#
# Created: Fri Nov 20 13:19:43 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_addDialog(object):
    def setupUi(self, addDialog):
        addDialog.setObjectName("addDialog")
        addDialog.setWindowModality(QtCore.Qt.ApplicationModal)
        addDialog.resize(301, 111)
        self.verticalLayout = QtGui.QVBoxLayout(addDialog)
        self.verticalLayout.setObjectName("verticalLayout")
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.label_2 = QtGui.QLabel(addDialog)
        self.label_2.setMinimumSize(QtCore.QSize(40, 0))
        self.label_2.setMaximumSize(QtCore.QSize(67, 16777215))
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 0, 1, 1)
        self.pathdlgEdit = QtGui.QLineEdit(addDialog)
        self.pathdlgEdit.setMaximumSize(QtCore.QSize(134, 16777215))
        self.pathdlgEdit.setObjectName("pathdlgEdit")
        self.gridLayout.addWidget(self.pathdlgEdit, 0, 1, 1, 1)
        self.openPathButton = QtGui.QPushButton(addDialog)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/images/open.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.openPathButton.setIcon(icon)
        self.openPathButton.setIconSize(QtCore.QSize(16, 16))
        self.openPathButton.setObjectName("openPathButton")
        self.gridLayout.addWidget(self.openPathButton, 0, 2, 1, 1)
        self.label = QtGui.QLabel(addDialog)
        self.label.setMinimumSize(QtCore.QSize(40, 0))
        self.label.setMaximumSize(QtCore.QSize(67, 16777215))
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.namedlgEdit = QtGui.QLineEdit(addDialog)
        self.namedlgEdit.setMaximumSize(QtCore.QSize(134, 16777215))
        self.namedlgEdit.setObjectName("namedlgEdit")
        self.gridLayout.addWidget(self.namedlgEdit, 1, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.errordlgLabel = QtGui.QLabel(addDialog)
        self.errordlgLabel.setObjectName("errordlgLabel")
        self.horizontalLayout_3.addWidget(self.errordlgLabel)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem)
        self.adddlgButton = QtGui.QPushButton(addDialog)
        self.adddlgButton.setObjectName("adddlgButton")
        self.horizontalLayout_3.addWidget(self.adddlgButton)
        self.canceldlgButton = QtGui.QPushButton(addDialog)
        self.canceldlgButton.setObjectName("canceldlgButton")
        self.horizontalLayout_3.addWidget(self.canceldlgButton)
        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.retranslateUi(addDialog)
        QtCore.QMetaObject.connectSlotsByName(addDialog)

    def retranslateUi(self, addDialog):
        addDialog.setWindowTitle(QtGui.QApplication.translate("addDialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("addDialog", "Path:", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("addDialog", "Name:", None, QtGui.QApplication.UnicodeUTF8))
        self.errordlgLabel.setText(QtGui.QApplication.translate("addDialog", "TextLabel", None, QtGui.QApplication.UnicodeUTF8))
        self.adddlgButton.setText(QtGui.QApplication.translate("addDialog", "Add", None, QtGui.QApplication.UnicodeUTF8))
        self.canceldlgButton.setText(QtGui.QApplication.translate("addDialog", "Cancel", None, QtGui.QApplication.UnicodeUTF8))

import Dcat_rc
