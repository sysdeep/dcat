# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file './dcat/rc/add_progress_dlg.ui'
#
# Created: Fri Nov 20 13:19:44 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_addProgressDialog(object):
    def setupUi(self, addProgressDialog):
        addProgressDialog.setObjectName("addProgressDialog")
        addProgressDialog.resize(412, 199)
        self.horizontalLayout = QtGui.QHBoxLayout(addProgressDialog)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.progressBar = QtGui.QProgressBar(addProgressDialog)
        self.progressBar.setProperty("value", QtCore.QVariant(24))
        self.progressBar.setObjectName("progressBar")
        self.verticalLayout.addWidget(self.progressBar)
        self.pushButton = QtGui.QPushButton(addProgressDialog)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        self.addLabel = QtGui.QLabel(addProgressDialog)
        self.addLabel.setObjectName("addLabel")
        self.verticalLayout.addWidget(self.addLabel)
        self.goButton = QtGui.QPushButton(addProgressDialog)
        self.goButton.setObjectName("goButton")
        self.verticalLayout.addWidget(self.goButton)
        self.horizontalLayout.addLayout(self.verticalLayout)

        self.retranslateUi(addProgressDialog)
        QtCore.QObject.connect(self.pushButton, QtCore.SIGNAL("clicked()"), addProgressDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(addProgressDialog)

    def retranslateUi(self, addProgressDialog):
        addProgressDialog.setWindowTitle(QtGui.QApplication.translate("addProgressDialog", "Adding...", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton.setText(QtGui.QApplication.translate("addProgressDialog", "Close", None, QtGui.QApplication.UnicodeUTF8))
        self.addLabel.setText(QtGui.QApplication.translate("addProgressDialog", "addLabel", None, QtGui.QApplication.UnicodeUTF8))
        self.goButton.setText(QtGui.QApplication.translate("addProgressDialog", "go", None, QtGui.QApplication.UnicodeUTF8))

