# -*- coding: utf-8 -*-
'''
'''

#python imports
import platform, os, sys

#PyQt imports



#=======================================================================
# globals / constants

PROGRAM_NAME = "Dcat"
PROGRAM_VERSION_MAJOR = 0
PROGRAM_VERSION_MINOR = 1
PROGRAN_VERSION = (PROGRAM_VERSION_MAJOR,
                   PROGRAM_VERSION_MINOR)

PROGRAM_VERSION_TEXT = "%d.%d" % (PROGRAM_VERSION_MAJOR,
                                  PROGRAM_VERSION_MINOR)

#BASEDIR = unicode(os.path.dirname(__file__))
#IMAGE_DIR = u"images"
#NODE_ICON_DIR = os.path.join(IMAGE_DIR, u"node_icons")
PLATFORM = None


BASEDIR = unicode(os.path.dirname(__file__))



#=======================================================================
# application resources

def get_basedir():
    return os.path.dirname(__file__)

def set_basedir(basedir):
    global BASEDIR
    BASEDIR = basedir






#=======================================================================
# common functions

def get_platform():
    """Returns a string for the current platform"""
    global PLATFORM
    
    PLATFORM = platform.system()
                        
    return PLATFORM


FS_ENCODING = object()
def ensure_unicode(text, encoding="utf8"):
    """Ensures a string is unicode"""

    if text is None:
        return None

    if not isinstance(text, unicode):
        if encoding == FS_ENCODING:
            return unicode(text, sys.getfilesystemencoding())
        else:
            return unicode(text, encoding)
    return text


def unicode_fs(text):
    """Converts a string from the filesystem to unicode"""

    if text is None:
        return None

    if not isinstance(text, unicode):
        if encoding == FS_ENCODING:
            return unicode(text, sys.getfilesystemencoding())
    
    return text






