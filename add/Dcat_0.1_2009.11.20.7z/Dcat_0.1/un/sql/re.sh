#!/bin/bash
#

rm 1.bd
sqlite3 1.bd < 1.sql
