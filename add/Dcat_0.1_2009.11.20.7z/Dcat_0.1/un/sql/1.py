#!/bin/env python
#-*- coding: utf-8 -*-
#1.py
#test sqlite

import os, string
import sqlite


#=======================================================================
#

#=======================================================================

def all_bd(cu):	#all sqlite nodes
	cu.execute("select * from tree")
	row=cu.fetchall()
	print "sql level, rk, lk, id, name: "
	print row
	print

def get_all_tree(cu):	#return all tree
	query="SELECT id, name, level FROM tree ORDER BY lk"
	cu.execute(query)
	row=cu.fetchall()
	return row

def add_node(cu, rk, level, name):	#add node
	query1="UPDATE tree SET lk = lk + 2, rk = rk + 2 WHERE lk > "+str(rk)+""
	query2="UPDATE tree SET rk = rk + 2 WHERE rk >= "+str(rk)+" AND lk < "+str(rk)+""
	query3="INSERT INTO tree (lk, rk, level, name) values ("+str(rk)+", "+str((rk+1))+", "+str((level+1))+", '"+name+"')"
	cu.execute(query1)
	cu.execute(query2)
	cu.execute(query3)
	
#поиск rk и level по имени записи
#out:	rk,level	
def search_rk_level(cu, name):
	query="SELECT rk, level FROM tree where name='"+name+"'"
	cu.execute(query)
	row=cu.fetchone()
	return row
	
	
def walkdir(dir, cu):
	for root, dirs, files in os.walk(dir):
		roots=string.split(root,"/")		#получаем имя родителя
		name=roots[len(roots)-1]			#
		print "Name---->"+name	
		#rk, level = search_rk_level(cu, name)
		
		if(dirs):
			print "Dirs=======================:"
			for x in dirs:
				rk, level = search_rk_level(cu, name)
				add_node(cu, rk, level, x)
				print x
			
		if(files):	
			print "Files======================:"
			for x in files:
				rk, level = search_rk_level(cu, name)
				add_node(cu, rk, level, x)
				print x
		
		print
		
#=======================================================================
#connect bd
cx=sqlite.connect("1.bd",0777)
cu=cx.cursor()
#=======================================================================




##rk=6
##level=2
##name="dir3.2"
dir='./'


walkdir(dir, cu)

##all_bd(cu)
##add_node(cu, rk, level, name)
all_bd(cu)

row=get_all_tree(cu)
for x in row:
	ll="|"
	for a in range(x[2]):
		ll=ll+"  "
	print ll+x[1]





cx.commit()		#сохранение bd
	


