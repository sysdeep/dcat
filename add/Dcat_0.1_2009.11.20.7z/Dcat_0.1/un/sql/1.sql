BEGIN TRANSACTION;
CREATE TABLE tree (level int(10), rk int(10), lk int(10), id integer PRIMARY KEY, name varchar(150));
INSERT INTO "tree" (level, lk, rk, name) VALUES(0,1,2,'root');
CREATE INDEX lk on tree (lk,rk,level);
COMMIT;
