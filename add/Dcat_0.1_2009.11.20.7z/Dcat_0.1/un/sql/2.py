#!/bin/env python
#-*- coding: utf-8 -*-
#1.py
#test sqlite

import os, string, sys
import sqlite3


#=======================================================================
#

#=======================================================================

def all_bd(cu):	#all sqlite nodes
	cu.execute("select * from tree")
	row=cu.fetchall()
	print "sql level, rk, lk, id, name: "
	print row
	print


#======================================
def get_all_tree(cu):	#return all tree
    ''' 
    get_all_tree(cu)
    получаем дерево id, name, level
    in:  	cu.cursor
    out:  	list[id, name, level]
    '''

    query="SELECT id, name, level FROM tree ORDER BY lk"
    cu.execute(query)
    row=cu.fetchall()
    return row 	# id, name, level

#======================================
def get_from_lk(cu, lk):
    
    '''
    get_from_lk(cu, lk)
    получаем данные по левому ключу
    in:  	cu.cursor, lk
    out: 	list(rk, level, name)
    '''
    
    query_search_node="select rk, level, name from tree WHERE lk="+str(lk)+""
    cu.execute(query_search_node)
    row=cu.fetchone()
    return row
	
#======================================
def add_node(cu, lk, name):	#add node
	
    '''
    add_node(cu, lk, name)
    заносим запись в базу
    in:  	cu.cursor, rk, level, name
    out: 	---
    '''
    
    level=get_from_lk(cu, lk)[1]
    rk=get_from_lk(cu, lk)[0]
    query1="UPDATE tree SET lk = lk + 2, rk = rk + 2 WHERE lk > "+str(rk)+""
    query2="UPDATE tree SET rk = rk + 2 WHERE rk >= "+str(rk)+" AND lk < "+str(rk)+""
    query3="INSERT INTO tree (lk, rk, level, name) values ("+str(rk)+", "+str((rk+1))+", "+str((level+1))+", '"+name+"')"
    cu.execute(query1)
    cu.execute(query2)
    cu.execute(query3)
	
   
#======================================
def search_valid_parent(cu, root):
    
    '''
    search_valid_parent(cu, root)
    поиск lk правильного предка
    in:	    cu.cursor, root(путь от корня нашей базы: root/item1/dir1)
    out:	lk
    '''
    
    #root = ["root", "item1", "dir1"] - dir1 - #имя предка 
    name=root[len(root)-1]        #имя предка
        
    #ищем все lk с именем name
    query = "SELECT lk, rk FROM tree where name='"+name+"'"
    cu.execute(query)
    row=cu.fetchall()   #lk и rk всех элементов с именем name
    
    #для всех значений ищем предка
    #если нашли первый совпадающий - то выходим и возвращаем текущий lk
    for x in row:
        lk = x[0]
        rk = x[1]
        #ищем для текущего name путь предков
        query ="SELECT name FROM tree WHERE lk <= "+str(lk)+" AND rk >= "+str(rk)+" ORDER BY lk"
        cu.execute(query)
        row=cu.fetchall() #[ (u'root'), ('item1') ]
                
        #теперь последовательно сравниваем значения из root и row
        #root=[ u'root', 'item1' ], row=[ (u'root'), ('item1') ]
        flag="false"    #флаг
        c=0             #начальный элемент
        
        for z in row:
            a = root[c]     #'root', 'item1'
            b = z[0].encode("utf8")        #'root', item1(из unikode в str)
            if a==b:
                pass        #flag остается false
            else:
                flag="true" #несовпадение
                break
            c=c+1
            
                
        #если полное совпадение, то выходим из цикла и возвращаем lk
        if flag=="false":
            break
                   
    return lk
	
    

#======================================
#дерево дир в базу
#in:	base dir, cu.cursor, start_node - куда забивать = 
#out:	---
#================
def walkdir(dir, cu, name_item, cx):
    
    '''
    walkdir(dir, cu, name_item, cx)
    дерево дир в базу
    in:	    dir - откуда начинается сканирование(срока должна заканчиавться /), 
            cu.cursor, 
            cx - индефикатор базы
            name_item - имя нашего раздела(item1) 
    out:	---
    '''
	
    #добавляем в базу название нашего раздела
    #ищем lk у корня
    query = "SELECT lk FROM tree WHERE level=0"
    cu.execute(query)
    row=cu.fetchone()   #(int,)
            
    lk = row[0]
    add_node(cu, lk, name_item)
        
    #ищем lk нашего добавленного раздела
    query = "SELECT lk, rk FROM tree WHERE name='"+name_item+"' AND level=1"
    cu.execute(query)
    row=cu.fetchone()   #(2,3)
          
    lk = row[0]
    rk = row[1]
        
    prefix=["root", "label1"]    #root/+наш раздел
    
    #разбиваем путь на лист
    rdirs = string.split(dir, "/")
    flag = "false"  #нужен для отлова 1 прохода
    #в цикле обходим все диры
    for root, dirs, files in os.walk(dir):
        #root - текущий путь(от корня) в данной итерации
        #dirs - список дир в данной итерации
        #files - список фаилов в данной итерации
        
        #если 1 раз, то не ищем предка
        if flag=="false":   
            flag="true"     #и сразу ставим другой флаг
        else:   #в противном случае - ищем
            
            roots=string.split(root,"/")		#разбиваем строку ("","path1","path2")
            #избавляемся от системного префикса
            for x in range(len(rdirs)-1):
                roots.remove(roots[0])  #удаляем по одному с начала
            new_root=prefix+roots       # root, item1 + дальнейшие элементы
            
            #ищем lk от правильного предка 
            lk=search_valid_parent(cu, new_root)
                        
        if(dirs):
			for x in dirs:      #x - name
				add_node(cu, lk, x)
		
        
        if(files):	
			for x in files:     #x - name
				add_node(cu, lk, x)
				
        #подтверждение транзакции(иначе в поиске предков ничего не выберется(()
        cx.commit()
        

		
#=======================================================================
#main===================================================================


#=======================================================================
#connect bd
cx=sqlite3.connect("../1.ddb",0777)
cu=cx.cursor()
#=======================================================================


dir='/home/diver/Wrk/Comcon/'
root_item=1
name_item="label3"


#=======================================================================
#
if(len(sys.argv)==1):		    # no arguments
	#all_bd(cu)

	row=get_all_tree(cu)	    # id, name, level
	for x in row:
		ll=""
		for a in range(x[2]):	#level
			ll=ll+">"
		ll=ll+"-"
		print ll+x[1]			#name

elif(sys.argv[1]=="add"):	    #add
	print "add"
	
	walkdir(dir, cu, name_item, cx)
    #walkdir(dir, cu, root_item)
	
elif(sys.argv[1]=="remove"):	#remove
	print "remove"




cx.commit()		#сохранение bd
	


