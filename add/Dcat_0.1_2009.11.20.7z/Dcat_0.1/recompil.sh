pyuic4 ./dcat/rc/main_window.ui -o ./dcat/gui/main_window_ui.py
pyuic4 ./dcat/rc/add_node_dlg.ui -o ./dcat/gui/add_node_dlg_ui.py
pyuic4 ./dcat/rc/rename_dlg.ui -o ./dcat/gui/rename_dlg_ui.py
pyuic4 ./dcat/rc/add_progress_dlg.ui -o ./dcat/gui/add_progress_dlg_ui.py

pyrcc4 ./dcat/rc/Dcat.qrc -o ./dcat/gui/Dcat_rc.py
