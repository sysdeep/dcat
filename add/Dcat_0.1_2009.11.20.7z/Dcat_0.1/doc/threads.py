#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Вот примерно так оно делается.

import sys
from PyQt4.QtCore import QEvent, QThread
from PyQt4.QtGui import QApplication, QTextEdit

class MyEvent(QEvent):
    def __init__(self, data):
        QEvent.__init__(self, QEvent.User)
        self.data = data

class Timer(QThread):
    def __init__(self, event_receiver):
        QThread.__init__(self)
        self.event_receiver = event_receiver
        self.time = 0
    def run(self):
        while True:
            self.time += 1
            QApplication.postEvent(self.event_receiver, MyEvent(self.time))
            self.sleep(1)

class Display(QTextEdit):
    def customEvent(self, event):
        if isinstance (event, MyEvent):
            self.append('time = %i' % event.data)

a = QApplication(sys.argv)
display = Display()
display.show()

timer = Timer(display)
timer.start()

sys.exit(a.exec_())
