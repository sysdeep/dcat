from ttkthemes.themed_tk import ThemedTk
from ttkthemes.themed_style import ThemedStyle
